plain ascii content
